//
//  ViewController.swift
//  firepaste
//
//  Created by Malik Morenigbade on 11/21/17.
//  Copyright © 2017 Malik Morenigbade. All rights reserved.
//

import Cocoa
import FirebaseCommunity
class ViewController: NSViewController,NSUserNotificationCenterDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        var ref: DatabaseReference!
        ref = Database.database().reference()
        ref.child("text").observe(.value, with: { (snapshot) -> Void in
            print(snapshot.value as! String)
            //copy to clipboard
            let pasteboard = NSPasteboard.general
            pasteboard.clearContents()
            pasteboard.setString(snapshot.value as! String, forType: NSPasteboard.PasteboardType.string)
            self.showNotification(message: "Text copied to clipboard")
        })
    }
    
    func showNotification(message:String) -> Void {
        let notification = NSUserNotification()
        notification.title = "Firepaste"
        notification.subtitle = message
        notification.soundName = NSUserNotificationDefaultSoundName
        NSUserNotificationCenter.default.delegate = self
        NSUserNotificationCenter.default.deliver(notification)
    }
    
    func userNotificationCenter(_ center: NSUserNotificationCenter,
                                shouldPresent notification: NSUserNotification) -> Bool {
        return true
    }
    
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

