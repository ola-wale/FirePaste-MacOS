//
//  AppDelegate.swift
//  firepaste
//
//  Created by Malik Morenigbade on 11/21/17.
//  Copyright © 2017 Malik Morenigbade. All rights reserved.
//

import Cocoa
import LaunchAtLogin
import FirebaseCommunity

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate,NSUserNotificationCenterDelegate {
    
    @IBOutlet weak var statusMenu: NSMenu!
    @IBOutlet weak var quit: NSMenuItem!
    let controlNotification:NSMenuItem = NSMenuItem(title: "Enable Notification", action: #selector(AppDelegate.toggleNotification(_:)), keyEquivalent: "")
    let statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)

    override init() {
        //launch on login
        LaunchAtLogin.isEnabled = true
        FirebaseApp.configure()
    }
    
    @objc func terminate(_ sender: Any?) {}
    
    @objc func toggleNotification(_ sender: Any?) {
        let notificationStatus = AppDelegate.readList(key:"enableNotification");
        AppDelegate.editList(key:"enableNotifications",value:!notificationStatus)
        if(AppDelegate.readList(key:"enableNotifications")){
            controlNotification.title = "Disable Notification"
        } else {
            controlNotification.title = "Enable Notification"
        }
    }

    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
        
        //status bar setup
        let icon = NSImage(named:NSImage.Name(rawValue: "statusIcon"))
        icon?.isTemplate = true
        statusItem.image = icon
        let menu = NSMenu()
        menu.addItem(controlNotification)
        menu.addItem(NSMenuItem.separator())
        menu.addItem(NSMenuItem(title: "Quit", action: #selector(AppDelegate.terminate(_:)), keyEquivalent: ""))
        statusItem.menu = menu
        
        if(AppDelegate.readList(key:"enableNotifications")){
            controlNotification.title = "Disable Notification"
        }

        var ref: DatabaseReference!
        ref = Database.database().reference()
        ref.observe(.childChanged, with: { (snapshot) -> Void in
            //copy to clipboard
            let pasteboard = NSPasteboard.general
            pasteboard.clearContents()
            pasteboard.setString(snapshot.value as! String, forType: NSPasteboard.PasteboardType.string)
            if(AppDelegate.readList(key:"enableNotifications")){
                self.showNotification(message: "Text copied to clipboard")
            }
        })
        
    }
    

    
    func applicationDidFinishLaunchingWithOptions(_ aNotification: Notification) {
        // Insert code here to initialize your application
        
    }
    

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }
    
    
    func showNotification(message:String) -> Void {
        let notification = NSUserNotification()
        notification.title = "Firepaste"
        notification.subtitle = message
        notification.soundName = NSUserNotificationDefaultSoundName
        NSUserNotificationCenter.default.delegate = self
        NSUserNotificationCenter.default.deliver(notification)
    }
    
    func userNotificationCenter(_ center: NSUserNotificationCenter,
                                shouldPresent notification: NSUserNotification) -> Bool {
        return true
    }
    
    public static func editList(key:String,value:Bool){
        let path = Bundle.main.path(forResource: "config", ofType: "plist")
        if let dict = NSMutableDictionary(contentsOfFile: path!) {
            dict.setValue(value, forKey: key)
            dict.write(toFile: path!, atomically: false)
        }
    }
    
    public static func readList(key:String) -> Bool{
        let path = Bundle.main.path(forResource: "config", ofType: "plist")
        let dict = NSMutableDictionary(contentsOfFile: path!)
        return (dict!.value(forKey: key)! as! Bool)
    }
}
